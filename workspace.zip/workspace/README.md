# Code Challenges

Below are the instructions for running spell check program.

 SpellChecker.java - it is main a program which will receive inputs (*.txt) as given below and perform spell checks
 
 1. Import the Java project in IDE
 2. In command line, go to path where you have (SpellChecker.java)  
       Ex.  C:\Personal\workspace\src>
 3. Compile java file with the below command
       javac SpellChecker.java
 4. Run java class with below command.
       java SpellChecker dictionary.txt spellcheck.txt

Note: Both txt files are available in the same location. 
Also if there is any change in spellcheck.txt (like modifying the inputs) , please compile SpellChecker.java and then run it with 'run' command.

            
