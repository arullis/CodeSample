import com.codechallenge.spellcheck.processor.SpellCheckProcessor;

import java.util.HashMap;
import java.util.Map;

import com.codechallenge.spellcheck.util.SpellCheckConstants;

public class SpellChecker {

    public static void main(String args[]){
        try {
            String dictionaryFileName = args[0];
            String spellCheckFileName = args[1];
            Map<String, String> inputFileNameList = new HashMap<>();
            inputFileNameList.put(SpellCheckConstants.DICTIONARY_FILE, dictionaryFileName);
            inputFileNameList.put(SpellCheckConstants.SPELL_CHECK_FILE, spellCheckFileName);
            SpellCheckProcessor spellCheckProcessor = new SpellCheckProcessor();
            spellCheckProcessor.processSpellCheck(inputFileNameList);
        }
        catch(ArrayIndexOutOfBoundsException exception){
            System.out.println("Enter valid txt file names as arguments - e.g. java SpellChecker dictionary.txt spellcheck.txt");
        }
    }
}
