package com.codechallenge.spellcheck.exception;

public class SpellCheckException extends RuntimeException{

    private String errorMessage;

    public SpellCheckException(String errorMessage) {
        super(errorMessage);
        this.errorMessage=errorMessage;
    }
    public SpellCheckException() {
        super();
    }

    public SpellCheckException(
            String errorMessage, Throwable cause) {
        super(errorMessage, cause);
        this.errorMessage=errorMessage;
    }


}
