package com.codechallenge.spellcheck.model;

import java.util.List;

public class SpellCheckDetails {
    private String word;
    boolean isIncorrectWord;
    List<String> suggestedWordList;
    int line;
    int column;

    public String getWord() {
        return word;
    }

    public void setWord(String word) {
        this.word = word;
    }

    public boolean isIncorrectWord() {
        return isIncorrectWord;
    }

    public void setIncorrectWord(boolean incorrectWord) {
        isIncorrectWord = incorrectWord;
    }

    public List<String> getSuggestedWordList() {
        return suggestedWordList;
    }

    public void setSuggestedWordList(List<String> suggestedWordList) {
        this.suggestedWordList = suggestedWordList;
    }

    public int getLine() {
        return line;
    }

    public void setLine(int line) {
        this.line = line;
    }

    public int getColumn() {
        return column;
    }

    public void setColumn(int column) {
        this.column = column;
    }
}
