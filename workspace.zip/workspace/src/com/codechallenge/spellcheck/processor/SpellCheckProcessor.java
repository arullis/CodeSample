package com.codechallenge.spellcheck.processor;

import com.codechallenge.spellcheck.exception.SpellCheckException;
import com.codechallenge.spellcheck.model.SpellCheckDetails;
import com.codechallenge.spellcheck.util.FileReader;
import com.codechallenge.spellcheck.util.SpellCheckConstants;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * This class is to read the dictionary and spell check file and perform the spell check for given words
 */
public class SpellCheckProcessor {

    private DictionaryNode dictionaryRootNode;

    /***
     * For keeping dictionary words in Tries
     */
    private static class DictionaryNode{
        Character letter;
        Map<Character, DictionaryNode> dictionaryMap;
        boolean isWordCompleted;
        public DictionaryNode(){
            dictionaryMap=new HashMap<>();
        }
        public DictionaryNode(Character letter){
            dictionaryMap=new HashMap<>();
            this.letter=letter;
            dictionaryMap.put(letter,new DictionaryNode());
        }
    }

    public SpellCheckProcessor(){
        dictionaryRootNode=new DictionaryNode();
    }

    /**
     * Read the dictionary and spell check words from file and initiate
     *  the spell check process
     * @param inputFileNameList
     * @return
     */
    public void processSpellCheck(Map<String,String> inputFileNameList){
        try {
          List<String>  dictionaryList= FileReader.getFileListByName(
                  inputFileNameList.get(SpellCheckConstants.DICTIONARY_FILE));
          addWordsToDictionary(dictionaryList);
          List<String>  spellCheckWordList=  FileReader.getFileListByName(
                  inputFileNameList.get(SpellCheckConstants.SPELL_CHECK_FILE));
         List<SpellCheckDetails> spellCheckDetailsList= performSpellCheck(spellCheckWordList);
         if(spellCheckDetailsList!=null && !spellCheckDetailsList.isEmpty()){
           List<String> misSpellWordList=
                   spellCheckDetailsList.stream().map(SpellCheckDetails::getWord).collect(Collectors.toList());
            System.out.println("*************************************************");
             System.out.println("misSpellWordList:"+misSpellWordList);
             for(SpellCheckDetails spellCheckDetail: spellCheckDetailsList){
                 System.out.println("MisSpellWord:"+spellCheckDetail.getWord());
                 System.out.println("MisSpellWord Line:"+spellCheckDetail.getLine());
                 System.out.println("MisSpellWord Column:"+spellCheckDetail.getColumn());
                 System.out.println("SuggestedWordList:"+spellCheckDetail.getSuggestedWordList());
             }
             System.out.println("*************************************************");
         }

        } catch (IOException exception) {
            throw new SpellCheckException("Error while processing the file. Please check the input file name",exception);
        }
    }

    /**
     * To add the list of dictionary words into Tries
     * @param dictionaryList
     */
    private void addWordsToDictionary( List<String>  dictionaryList){
        if(!dictionaryList.isEmpty()){
            for(String dictionary: dictionaryList){
                DictionaryNode currentDictionaryNode= dictionaryRootNode;
                for(int i=0;i<dictionary.length();i++){
                    char dictionaryLetter=dictionary.charAt(i);
                    if(!currentDictionaryNode.dictionaryMap.containsKey(dictionaryLetter)){
                        currentDictionaryNode.dictionaryMap.put(
                                dictionaryLetter,new DictionaryNode(dictionaryLetter));
                    }
                    currentDictionaryNode=currentDictionaryNode.dictionaryMap.get(dictionaryLetter);
                }
                currentDictionaryNode.isWordCompleted=true;
            }
        }
    }


    /***
     * Performs spell check for each spell word
     * @param spellCheckWordList
     * @return
     */
    private List<SpellCheckDetails>  performSpellCheck(List<String>  spellCheckWordList){
        List<SpellCheckDetails> processedSpellCheckList=null;
        if(!spellCheckWordList.isEmpty()){
            processedSpellCheckList=new ArrayList<>();
            for(int lineInd=0;lineInd<spellCheckWordList.size(); lineInd++){
                String spellcheckWord=spellCheckWordList.get(lineInd);
                if(spellcheckWord!=null && !isValidWord(spellcheckWord)) continue;
                SpellCheckDetails spellCheckDetails=getSpellCheckDetails(spellcheckWord.toLowerCase());
                if(spellCheckDetails!=null){
                    spellCheckDetails.setLine(lineInd+1);
                    processedSpellCheckList.add(spellCheckDetails);
                }
            }
        }
        return processedSpellCheckList;
    }

    /***
     * To check if it is valid string based on the pattern
     * @param spellCheckWord
     * @return
     */
    private boolean isValidWord(String spellCheckWord){
        String spellCheckPattern="[A-Za-z]+";
        Pattern pattern=Pattern.compile(spellCheckPattern);
        Matcher matcher=pattern.matcher(spellCheckWord);
        if(matcher.matches()) return true;
        return false;
    }

    /**
     * Returns SpellCheckDetails object if given word is mis spelled.
     * @param spellCheckWord
     * @return
     */
    private SpellCheckDetails getSpellCheckDetails(String spellCheckWord){
        int columnInd=1;
        SpellCheckDetails spellCheckDetails=null;
        DictionaryNode currentDictionaryNode= dictionaryRootNode;
        DictionaryNode previousDictionaryNode=null;
        StringBuffer word=new StringBuffer();
        int spellCheckWrdLength=spellCheckWord.length();
        for(int i=0;i<spellCheckWrdLength;i++,columnInd++){
            char spellcheckLetter=spellCheckWord.charAt(i);
            previousDictionaryNode=currentDictionaryNode;
            currentDictionaryNode=currentDictionaryNode.dictionaryMap.get(spellcheckLetter);
            if(currentDictionaryNode==null || currentDictionaryNode.dictionaryMap.isEmpty()) break;
            else if(!currentDictionaryNode.dictionaryMap.isEmpty())
                word.append(spellcheckLetter);
        }

        if(!isExactWordFound(currentDictionaryNode)) {
         if (previousDictionaryNode != null && !previousDictionaryNode.dictionaryMap.isEmpty()) {
                spellCheckDetails = new SpellCheckDetails();
                spellCheckDetails.setWord(spellCheckWord);
                spellCheckDetails.setIncorrectWord(true);
                spellCheckDetails.setColumn(columnInd);
                List<String> suggestedWordList = new ArrayList<>();
                getSuggestedWords(suggestedWordList, word, previousDictionaryNode);
                spellCheckDetails.setSuggestedWordList(suggestedWordList);
            }
        }
        return spellCheckDetails;
    }

    /**
     * To check if exact word is found
     * @param currentDictionaryNode
     * @return
     */
    private boolean isExactWordFound(DictionaryNode currentDictionaryNode){
        if(currentDictionaryNode!=null && currentDictionaryNode.isWordCompleted)
            return true;
        return false;
    }

    /**
     * To provide the list of suggested words for misspelled word
     * @param suggestedWordList
     * @param word
     * @param currentDictionaryNode
     */
    private void getSuggestedWords(List<String> suggestedWordList ,
                                   StringBuffer word,DictionaryNode currentDictionaryNode){
        if(currentDictionaryNode==null) return;

        if(currentDictionaryNode.dictionaryMap==null || currentDictionaryNode.dictionaryMap.isEmpty()) return;

        if(currentDictionaryNode.isWordCompleted) {
            suggestedWordList.add(word.toString());
        }
        for(DictionaryNode  dictionaryNode: currentDictionaryNode.dictionaryMap.values()){
            if(dictionaryNode.letter!=null) {
                word.append(dictionaryNode.letter);
                getSuggestedWords(suggestedWordList, word, dictionaryNode);
                word.setLength(word.length() - 1);
            }

        }

    }

}
