package com.codechallenge.spellcheck.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Utility class for file reading process
 */
public class FileReader {

    /**
     * Read the file and returns the words in list format
     * @param fileName
     * @return
     * @throws FileNotFoundException
     * @throws IOException
     */
    public static List<String> getFileListByName(String fileName) throws IOException{
        List<String> dictionaryList = null;

        if (fileName != null) {
            File file = new File(fileName);
            dictionaryList = new ArrayList<>();
           // System.out.println("file.getAbsolutePath():"+file.getAbsolutePath());
            try (BufferedReader reader = new BufferedReader(new
                    java.io.FileReader(file.getAbsolutePath()))) {
                while (true) {
                    String line = reader.readLine();
                    if (line == null)
                        break;
                    dictionaryList.add(line);
                }
            }

        }
        return dictionaryList;
    }
}

