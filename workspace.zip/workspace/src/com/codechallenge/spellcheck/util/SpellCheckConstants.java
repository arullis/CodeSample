package com.codechallenge.spellcheck.util;

public class SpellCheckConstants {

    public static final String DICTIONARY_FILE="DICTIONARY_FILE";
    public static final String SPELL_CHECK_FILE="SPELL_CHECK_FILE";
}
